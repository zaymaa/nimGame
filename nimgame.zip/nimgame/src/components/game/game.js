import { useState, useEffect, useCallback, useRef } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import "./game.css";

function Game({ onRestart }) {
    const [stones, setStones] = useState(7);
    const [playerTurn, setPlayerTurn] = useState(true);
    const [gameOver, setGameOver] = useState(false);
    const [winner, setWinner] = useState(null);
    const [gameHistory, setGameHistory] = useState([]);
    const [isThinking, setIsThinking] = useState(false);
    const [algorithm, setAlgorithm] = useState("minimax"); // "minimax" veya "alphabeta"
    const [treeData, setTreeData] = useState(null);
    const [stats, setStats] = useState({ nodes: 0, depth: 0, time: 0 });
    const [lastMove, setLastMove] = useState(null);
    const [activeTab, setActiveTab] = useState("visualization"); // "visualization" veya "performance"
    const [performanceData, setPerformanceData] = useState({
        minimax: [],
        alphabeta: [],
        testStones: null,
        testPlayerTurn: null
    });
    const [isRunningTests, setIsRunningTests] = useState(false);
    const [isTreeFullscreen, setIsTreeFullscreen] = useState(false);
    const nodeCountRef = useRef(0);
    const startTimeRef = useRef(0);

    // Minimax algoritması
    const minimax = useCallback((stonesLeft, isMaximizing, depth = 0, maxDepth = 5) => {
        nodeCountRef.current++;

        if (stonesLeft === 0) {
            return isMaximizing ? -1 : 1;
        }
        if (depth >= maxDepth) return 0;

        if (isMaximizing) {
            let bestScore = -Infinity;
            for (let i = 1; i <= Math.min(3, stonesLeft); i++) {
                const score = minimax(stonesLeft - i, false, depth + 1, maxDepth);
                bestScore = Math.max(bestScore, score);
            }
            return bestScore;
        } else {
            let bestScore = Infinity;
            for (let i = 1; i <= Math.min(3, stonesLeft); i++) {
                const score = minimax(stonesLeft - i, true, depth + 1, maxDepth);
                bestScore = Math.min(bestScore, score);
            }
            return bestScore;
        }
    }, []);

    // Alfa-Beta budamalı Minimax algoritması
    const alphabeta = useCallback((stonesLeft, isMaximizing, alpha, beta, depth = 0, maxDepth = 5) => {
        nodeCountRef.current++;

        if (stonesLeft === 0) {
            return isMaximizing ? -1 : 1;
        }
        if (depth >= maxDepth) return 0;

        if (isMaximizing) {
            let bestScore = -Infinity;
            for (let i = 1; i <= Math.min(3, stonesLeft); i++) {
                const score = alphabeta(stonesLeft - i, false, alpha, beta, depth + 1, maxDepth);
                bestScore = Math.max(bestScore, score);
                alpha = Math.max(alpha, bestScore);
                if (beta <= alpha) break; // Budama
            }
            return bestScore;
        } else {
            let bestScore = Infinity;
            for (let i = 1; i <= Math.min(3, stonesLeft); i++) {
                const score = alphabeta(stonesLeft - i, true, alpha, beta, depth + 1, maxDepth);
                bestScore = Math.min(bestScore, score);
                beta = Math.min(beta, bestScore);
                if (beta <= alpha) break; // Budama
            }
            return bestScore;
        }
    }, []);

    // Minimax ağacı oluştur (gerçek algoritmayı kullanarak)
    const buildMinimaxTree = useCallback((stonesLeft, isMaximizing, depth = 0, maxDepth = 5) => {
        nodeCountRef.current++;

        if (stonesLeft === 0) {
            return {
                stones: stonesLeft,
                score: isMaximizing ? -1 : 1,
                isMaximizing,
                depth,
                pruned: false,
                children: []
            };
        }
        if (depth >= maxDepth) {
            return {
                stones: stonesLeft,
                score: 0,
                isMaximizing,
                depth,
                pruned: false,
                children: []
            };
        }

        const node = {
            stones: stonesLeft,
            isMaximizing,
            depth,
            pruned: false,
            children: []
        };

        // Tüm olası hamleleri oluştur
        for (let i = 1; i <= Math.min(3, stonesLeft); i++) {
            const child = buildMinimaxTree(stonesLeft - i, !isMaximizing, depth + 1, maxDepth);
            node.children.push(child);
        }

        // Minimax mantığına göre skoru hesapla
        if (isMaximizing) {
            let bestScore = -Infinity;
            node.children.forEach((child) => {
                if (child.score > bestScore) {
                    bestScore = child.score;
                }
            });
            node.score = bestScore;
        } else {
            let bestScore = Infinity;
            node.children.forEach((child) => {
                if (child.score < bestScore) {
                    bestScore = child.score;
                }
            });
            node.score = bestScore;
        }

        return node;
    }, []);

    // Alfa-Beta budamalı ağaç oluştur (gerçek algoritmayı kullanarak, budanan dalları işaretle)
    const buildAlphaBetaTree = useCallback((stonesLeft, isMaximizing, alpha, beta, depth = 0, maxDepth = 5) => {
        nodeCountRef.current++;

        if (stonesLeft === 0) {
            return {
                stones: stonesLeft,
                score: isMaximizing ? -1 : 1,
                isMaximizing,
                depth,
                pruned: false,
                children: []
            };
        }
        if (depth >= maxDepth) {
            return {
                stones: stonesLeft,
                score: 0,
                isMaximizing,
                depth,
                pruned: false,
                children: []
            };
        }

        const node = {
            stones: stonesLeft,
            isMaximizing,
            depth,
            pruned: false,
            children: []
        };

        if (isMaximizing) {
            let bestScore = -Infinity;
            let prunedAfter = false;

            for (let i = 1; i <= Math.min(3, stonesLeft); i++) {
                if (prunedAfter) {
                    // Bu düğüm budandı (beta <= alpha olduğu için)
                    nodeCountRef.current++; // Budanan düğümler de görselleştirmede gösterildiği için sayılmalı
                    node.children.push({
                        stones: stonesLeft - i,
                        score: 0,
                        isMaximizing: false,
                        depth: depth + 1,
                        pruned: true,
                        children: []
                    });
                } else {
                    const child = buildAlphaBetaTree(stonesLeft - i, false, alpha, beta, depth + 1, maxDepth);
                    bestScore = Math.max(bestScore, child.score);
                    alpha = Math.max(alpha, bestScore);
                    node.children.push(child);

                    // Alfa-Beta budama kontrolü
                    if (beta <= alpha) {
                        prunedAfter = true;
                    }
                }
            }
            node.score = bestScore;
        } else {
            let bestScore = Infinity;
            let prunedAfter = false;

            for (let i = 1; i <= Math.min(3, stonesLeft); i++) {
                if (prunedAfter) {
                    // Bu düğüm budandı (beta <= alpha olduğu için)
                    nodeCountRef.current++; // Budanan düğümler de görselleştirmede gösterildiği için sayılmalı
                    node.children.push({
                        stones: stonesLeft - i,
                        score: 0,
                        isMaximizing: true,
                        depth: depth + 1,
                        pruned: true,
                        children: []
                    });
                } else {
                    const child = buildAlphaBetaTree(stonesLeft - i, true, alpha, beta, depth + 1, maxDepth);
                    bestScore = Math.min(bestScore, child.score);
                    beta = Math.min(beta, bestScore);
                    node.children.push(child);

                    // Alfa-Beta budama kontrolü
                    if (beta <= alpha) {
                        prunedAfter = true;
                    }
                }
            }
            node.score = bestScore;
        }

        return node;
    }, []);

    // Ağaç derinliklerini bul
    const getTreeDepths = useCallback((node) => {
        if (!node) return [0];
        if (!node.children || node.children.length === 0) return [node.depth || 0];
        return [node.depth || 0, ...node.children.flatMap(getTreeDepths)];
    }, []);

    // En iyi hamleyi bul ve ağaç yapısını oluştur (bilgisayar hamlesi için)
    const getBestMove = useCallback((stonesLeft) => {
        nodeCountRef.current = 0;
        startTimeRef.current = performance.now();

        // Gerçek arama ağacını oluştur (bilgisayarın sırası MIN)
        const searchTree = algorithm === "minimax"
            ? buildMinimaxTree(stonesLeft, false) // Bilgisayar MIN, oyuncu MAX
            : buildAlphaBetaTree(stonesLeft, false, -Infinity, Infinity); // Bilgisayar MIN, oyuncu MAX

        // Ağacı kaydet (görselleştirme için)
        setTreeData(searchTree);

        // Ağaçtan en iyi hamleyi bul
        let bestMove = 1;
        let bestScore = Infinity; // MIN oyuncu için en küçük skor en iyisidir

        for (let i = 1; i <= Math.min(3, stonesLeft); i++) {
            const child = searchTree.children[i - 1];
            if (child && child.score < bestScore) {
                bestScore = child.score;
                bestMove = i;
            }
        }

        // nodeCountRef değerini hemen sakla
        const nodeCount = nodeCountRef.current;
        
        const endTime = performance.now();
        const depths = getTreeDepths(searchTree);
        const maxDepth = depths.length > 0 ? Math.max(...depths) : 0;

        setStats({
            nodes: nodeCount,
            depth: maxDepth,
            time: parseFloat((endTime - startTimeRef.current).toFixed(2))
        });

        return bestMove;
    }, [algorithm, buildMinimaxTree, buildAlphaBetaTree, getTreeDepths]);

    // Her hamlede performans ölçümleri yap (otomatik)
    const runAutomaticPerformanceTests = useCallback(async (currentStones, currentPlayerTurn) => {
        if (currentStones === 0) {
            setPerformanceData({
                minimax: [],
                alphabeta: [],
                testStones: 0,
                testPlayerTurn: currentPlayerTurn
            });
            return;
        }

        const depths = [1, 2, 3, 4, 5, 6, 7];
        const minimaxResults = [];
        const alphabetaResults = [];

        // Asenkron olarak çalıştır ki UI donmasın
        setTimeout(() => {
            for (const depth of depths) {
                // Minimax testi
                nodeCountRef.current = 0;
                startTimeRef.current = performance.now();

                minimax(currentStones, !currentPlayerTurn, 0, depth);

                const minimaxTime = performance.now() - startTimeRef.current;

                minimaxResults.push({
                    depth,
                    nodes: nodeCountRef.current,
                    time: parseFloat(minimaxTime.toFixed(2))
                });

                // Alfa-Beta testi
                nodeCountRef.current = 0;
                startTimeRef.current = performance.now();

                alphabeta(currentStones, !currentPlayerTurn, -Infinity, Infinity, 0, depth);

                const alphabetaTime = performance.now() - startTimeRef.current;

                alphabetaResults.push({
                    depth,
                    nodes: nodeCountRef.current,
                    time: parseFloat(alphabetaTime.toFixed(2))
                });
            }

            setPerformanceData({
                minimax: minimaxResults,
                alphabeta: alphabetaResults,
                testStones: currentStones,
                testPlayerTurn: currentPlayerTurn
            });
        }, 100); // Kısa bir gecikme ile UI'ın donmasını önle
    }, [minimax, alphabeta]);

    // ESC tuşu ile fullscreen'i kapat
    useEffect(() => {
        const handleEscKey = (event) => {
            if (event.key === 'Escape' && isTreeFullscreen) {
                setIsTreeFullscreen(false);
            }
        };

        window.addEventListener('keydown', handleEscKey);
        return () => window.removeEventListener('keydown', handleEscKey);
    }, [isTreeFullscreen]);

    // Ağaç görselleştirmesini güncelle (oyuncu sırasındayken veya algoritma değiştiğinde)
    useEffect(() => {
        if (!gameOver && playerTurn) {
            // nodeCountRef'i sıfırla ve değeri sakla
            nodeCountRef.current = 0;
            startTimeRef.current = performance.now();

            // Oyuncu MAX olarak ağacı oluştur (oyuncunun bakış açısı)
            const tree = algorithm === "minimax"
                ? buildMinimaxTree(stones, true)
                : buildAlphaBetaTree(stones, true, -Infinity, Infinity);

            const endTime = performance.now();
            const depths = getTreeDepths(tree);
            const maxDepth = depths.length > 0 ? Math.max(...depths) : 0;
            
            // nodeCountRef değerini hemen sakla (runAutomaticPerformanceTests'ten önce)
            const nodeCount = nodeCountRef.current;

            setTreeData(tree);
            setStats({
                nodes: nodeCount,
                depth: maxDepth,
                time: parseFloat((endTime - startTimeRef.current).toFixed(2))
            });

            // Her hamlede otomatik performans testlerini çalıştır (nodeCountRef'i kendi içinde sıfırlayacak)
            runAutomaticPerformanceTests(stones, playerTurn);
        }
    }, [stones, playerTurn, gameOver, algorithm, buildMinimaxTree, buildAlphaBetaTree, runAutomaticPerformanceTests, getTreeDepths]);

    // Oyuncu hamlesi
    const handlePlayerMove = (taken) => {
        if (!playerTurn || gameOver || stones < taken) return;

        const newStones = stones - taken;
        setStones(newStones);
        setLastMove({ player: "Oyuncu", taken, stones: newStones });
        setGameHistory((prev) => [...prev, { player: "Oyuncu", taken, stones: newStones }]);

        if (newStones === 0) {
            setGameOver(true);
            setWinner("player");
            setPlayerTurn(false);
        } else {
            setPlayerTurn(false);
            setIsThinking(true);
        }
    };

    // AI hamlesi
    useEffect(() => {
        if (!playerTurn && !gameOver && stones > 0) {
            const timer = setTimeout(() => {
                const aiMove = getBestMove(stones);
                const newStones = stones - aiMove;
                setStones(newStones);
                setLastMove({ player: "Bilgisayar", taken: aiMove, stones: newStones });
                setGameHistory((prev) => [...prev, { player: "Bilgisayar", taken: aiMove, stones: newStones }]);
                setIsThinking(false);

                if (newStones === 0) {
                    setGameOver(true);
                    setWinner("ai");
                } else {
                    setPlayerTurn(true);
                }
            }, 1000);

            return () => clearTimeout(timer);
        }
    }, [playerTurn, gameOver, stones, getBestMove]);

    // Manuel performans testleri çalıştır (yeniden hesaplama için)
    const runManualPerformanceTests = useCallback(async () => {
        setIsRunningTests(true);
        await runAutomaticPerformanceTests(stones, playerTurn);
        setIsRunningTests(false);
    }, [stones, playerTurn, runAutomaticPerformanceTests]);

    const handleRestart = () => {
        setStones(7);
        setPlayerTurn(true);
        setGameOver(false);
        setWinner(null);
        setGameHistory([]);
        setLastMove(null);
        setIsThinking(false);
        setStats({ nodes: 0, depth: 0, time: 0 });
        if (onRestart) onRestart();
    };

    return (
        <div className="game-page">
            <div className="game-left">
                <div className="game-header">
                    <h2>Nim Oyunu</h2>
                    <button className="restart-btn" onClick={handleRestart}>
                        ↻ Yeniden Başlat
                    </button>
                </div>

                <div className="game-status">
                    <div className={`status-indicator ${playerTurn ? "player-turn" : "ai-turn"}`}>
                        {gameOver ? (
                            <span className="game-over-text">
                                {winner === "player" ? "🎉 Kazandınız!" : "🤖 Bilgisayar Kazandı!"}
                            </span>
                        ) : isThinking ? (
                            <span className="thinking">🤖 Bilgisayar düşünüyor...</span>
                        ) : (
                            <span>{playerTurn ? "👤 Sıra Sizde" : "🤖 Bilgisayarın Sırası"}</span>
                        )}
                    </div>
                </div>

                <div className="stones-container">
                    <div className="stones-label">Kalan Çubuk Sayısı</div>
                    <div className="stones-count">{stones}</div>
                    <div className="stones-visual">
                        {Array.from({ length: Math.min(stones, 20) }).map((_, i) => (
                            <div
                                key={i}
                                className={`stone ${lastMove && i >= stones ? "stone-removed" : ""}`}
                                style={{ animationDelay: `${i * 0.02}s` }}
                            >
                                🪨
                            </div>
                        ))}
                        {stones > 20 && <div className="stones-more">+{stones - 20} daha</div>}
                    </div>
                </div>

                <div className="move-buttons">
                    {[1, 2, 3].map((num) => (
                        <button
                            key={num}
                            className={`move-btn ${!playerTurn || gameOver || stones < num ? "disabled" : ""}`}
                            onClick={() => handlePlayerMove(num)}
                            disabled={!playerTurn || gameOver || stones < num}
                        >
                            {num} Al
                        </button>
                    ))}
                </div>

                {lastMove && (
                    <div className="last-move">
                        <span className="move-label">Son Hamle:</span>
                        <span className="move-text">
                            {lastMove.player} {lastMove.taken} çubuk aldı
                        </span>
                    </div>
                )}

                <div className="game-history">
                    <h3>Oyun Geçmişi</h3>
                    <div className="history-list">
                        {gameHistory.length === 0 ? (
                            <p className="no-history">Henüz hamle yok</p>
                        ) : (
                            gameHistory.slice(-5).reverse().map((move, idx) => (
                                <div key={idx} className="history-item">
                                    <span className={`history-player ${move.player === "Oyuncu" ? "player" : "ai"}`}>
                                        {move.player === "Oyuncu" ? "👤" : "🤖"} {move.player}
                                    </span>
                                    <span className="history-move">{move.taken} aldı</span>
                                    <span className="history-stones">{move.stones} kaldı</span>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>

            <div className="game-right">
                <div className="minimax-panel">
                    <div className="panel-tabs">
                        <button
                            className={`tab-btn ${activeTab === "visualization" ? "active" : ""}`}
                            onClick={() => setActiveTab("visualization")}
                        >
                            Görselleştirme
                        </button>
                        <button
                            className={`tab-btn ${activeTab === "performance" ? "active" : ""}`}
                            onClick={() => setActiveTab("performance")}
                        >
                            Performans Testleri
                        </button>
                    </div>

                    {activeTab === "visualization" && (
                        <>
                            <h3>Algoritma Görselleştirme</h3>

                            <div className="algorithm-switch">
                                <button
                                    className={`switch-btn ${algorithm === "minimax" ? "active" : ""}`}
                                    onClick={() => setAlgorithm("minimax")}
                                >
                                    Minimax
                                </button>
                                <button
                                    className={`switch-btn ${algorithm === "alphabeta" ? "active" : ""}`}
                                    onClick={() => setAlgorithm("alphabeta")}
                                >
                                    Alfa-Beta Budamalı Minimax
                                </button>
                            </div>

                            <div className="stats-container">
                                <div className="stat-item">
                                    <span className="stat-label">Ziyaret Edilen Düğüm:</span>
                                    <span className="stat-value">{treeData ? stats.nodes : 0}</span>
                                </div>
                                <div className="stat-item">
                                    <span className="stat-label">Arama Derinliği:</span>
                                    <span className="stat-value">{treeData ? stats.depth : 0}</span>
                                </div>
                                <div className="stat-item">
                                    <span className="stat-label">Çalışma Süresi:</span>
                                    <span className="stat-value">{treeData ? `${stats.time} ms` : '0 ms'}</span>
                                </div>
                            </div>

                            <div className="minimax-info">
                                <p className="info-text">
                                    {algorithm === "minimax"
                                        ? "Minimax algoritması tüm olası hamleleri değerlendirerek en iyi hamleyi bulur."
                                        : "Alfa-Beta budamalı Minimax, gereksiz dalları budayarak daha hızlı çalışır. Budanan dallar gri renkte gösterilir."}
                                </p>
                                {treeData && (
                                    <div className="tree-container">
                                        <button 
                                            className="tree-fullscreen-btn"
                                            onClick={() => setIsTreeFullscreen(true)}
                                            title="Tam Ekran"
                                        >
                                            ⛶
                                        </button>
                                        <MinimaxTreeView node={treeData} currentStones={stones} algorithm={algorithm} />
                                    </div>
                                )}
                                
                                {/* Fullscreen Modal */}
                                {isTreeFullscreen && treeData && (
                                    <div className="tree-fullscreen-modal" onClick={() => setIsTreeFullscreen(false)}>
                                        <div className="tree-fullscreen-content" onClick={(e) => e.stopPropagation()}>
                                            <div className="tree-fullscreen-header">
                                                <h3>Minimax Ağacı - Tam Ekran</h3>
                                                <button 
                                                    className="tree-fullscreen-close"
                                                    onClick={() => setIsTreeFullscreen(false)}
                                                    title="Kapat"
                                                >
                                                    ✕
                                                </button>
                                            </div>
                                            <div className="tree-fullscreen-container">
                                                <MinimaxTreeView node={treeData} currentStones={stones} algorithm={algorithm} />
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </>
                    )}

                    {activeTab === "performance" && (
                        <PerformanceTestPanel
                            onRunTests={runManualPerformanceTests}
                            isRunning={isRunningTests}
                            data={performanceData}
                        />
                    )}
                </div>
            </div>
        </div>
    );
}

// Performans Test Paneli Bileşeni
function PerformanceTestPanel({ onRunTests, isRunning, data }) {
    // Grafik verilerini hazırla
    const chartData = data.minimax && data.minimax.length > 0
        ? data.minimax.map((minimaxItem, index) => {
            const alphabetaItem = data.alphabeta[index];
            return {
                depth: minimaxItem.depth,
                minimaxNodes: minimaxItem.nodes,
                alphabetaNodes: alphabetaItem?.nodes || 0,
                minimaxTime: minimaxItem.time,
                alphabetaTime: alphabetaItem?.time || 0,
            };
        })
        : [];

    return (
        <div className="performance-panel">
            <h3>Performans Karşılaştırması</h3>

            <div className="test-controls">
                <p className="info-text">
                    Performans testleri <strong>her hamlede otomatik olarak</strong> mevcut oyun durumuna göre çalışır.
                    Farklı derinlik seviyelerinde (1-7) Minimax ve Alfa-Beta budamalı Minimax algoritmalarının performansını karşılaştırın.
                    {data.testStones && (
                        <span className="test-state-info">
                            <br />
                            <strong>Mevcut Test Durumu:</strong> {data.testStones} çubuk kaldı, {data.testPlayerTurn ? "Oyuncu" : "Bilgisayar"} sırası
                            <br />
                            <strong>Not:</strong> Grafikler her hamlede otomatik güncellenir.
                        </span>
                    )}
                </p>
                <button
                    className="test-btn"
                    onClick={onRunTests}
                    disabled={isRunning}
                >
                    {isRunning ? "Yeniden Hesaplanıyor..." : "Mevcut Durumda Yeniden Hesapla"}
                </button>
            </div>

            {chartData.length > 0 && (
                <>
                    <div className="chart-container">
                        <h4>Derinlik - Düğüm Sayısı Karşılaştırması</h4>
                        <ResponsiveContainer width="100%" height={300}>
                            <LineChart data={chartData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="depth" label={{ value: "Derinlik", position: "insideBottom", offset: -5 }} />
                                <YAxis label={{ value: "Düğüm Sayısı", angle: -90, position: "insideLeft" }} />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="minimaxNodes" stroke="#27ae60" strokeWidth={2} name="Minimax" />
                                <Line type="monotone" dataKey="alphabetaNodes" stroke="#e67e22" strokeWidth={2} name="Alfa-Beta" />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>

                    <div className="chart-container">
                        <h4>Derinlik - Çalışma Süresi Karşılaştırması</h4>
                        <ResponsiveContainer width="100%" height={300}>
                            <LineChart data={chartData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="depth" label={{ value: "Derinlik", position: "insideBottom", offset: -5 }} />
                                <YAxis label={{ value: "Süre (ms)", angle: -90, position: "insideLeft" }} />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="minimaxTime" stroke="#27ae60" strokeWidth={2} name="Minimax" />
                                <Line type="monotone" dataKey="alphabetaTime" stroke="#e67e22" strokeWidth={2} name="Alfa-Beta" />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>

                    <div className="performance-table">
                        <h4>Detaylı Sonuçlar</h4>
                        <table>
                            <thead>
                                <tr>
                                    <th>Derinlik</th>
                                    <th>Minimax Düğüm</th>
                                    <th>Alfa-Beta Düğüm</th>
                                    <th>Minimax Süre (ms)</th>
                                    <th>Alfa-Beta Süre (ms)</th>
                                </tr>
                            </thead>
                            <tbody>
                                {chartData.map((row, idx) => (
                                    <tr key={idx}>
                                        <td>{row.depth}</td>
                                        <td>{row.minimaxNodes}</td>
                                        <td>{row.alphabetaNodes}</td>
                                        <td>{row.minimaxTime}</td>
                                        <td>{row.alphabetaTime}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </>
            )}
        </div>
    );
}

// Minimax Ağaç Görselleştirme Bileşeni - Recursive yaklaşım
function MinimaxTreeView({ node, currentStones }) {
    if (!node) return null;

    const renderNode = (n, isRoot = false) => {
        const hasChildren = n.children && n.children.length > 0;
        
        return (
            <div className="tree-node-container">
                {/* Düğüm */}
                <div className="tree-node-wrapper">
                    {/* Yukarıdan gelen çizgi (root değilse) */}
                    {!isRoot && (
                        <div className={`tree-line-up ${n.pruned ? 'pruned-line' : ''}`} />
                    )}
                    
                    {/* Düğüm kutusu */}
                    <div
                        className={`tree-node-box
                            ${n.isMaximizing ? "max-node" : "min-node"}
                            ${n.pruned ? "pruned-node" : ""}
                            ${n.stones === currentStones ? "current-node" : ""}
                        `}
                    >
                        <div className="node-title">
                            {n.pruned ? "✂ Budandı" : n.isMaximizing ? "MAX" : "MIN"}
                        </div>
                        <div className="node-stones">{n.stones}</div>
                        {!n.pruned && (
                            <div className="node-score">score: {n.score}</div>
                        )}
                    </div>
                </div>

                {/* Çocuklar */}
                {hasChildren && (
                    <div className="tree-children-container">
                        {/* Parent'tan çocuklara giden çizgi */}
                        <div className={`tree-line-down ${n.pruned ? 'pruned-line' : ''}`} />
                        
                        {/* Çocuk düğümler */}
                        <div className={`tree-children-row ${n.pruned ? 'has-pruned' : ''} ${n.children.length > 1 ? 'has-siblings' : ''}`}>
                            {n.children.map((child, idx) => (
                                <div key={idx} className="tree-child-wrapper">
                                    {renderNode(child, false)}
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        );
    };

    return (
        <div className="minimax-tree">
            {renderNode(node, true)}
        </div>
    );
}


export default Game;
